jQuery(function ($) {
    $(document).ready(function () {
        // load google map
        var script = document.createElement('script');
        document.body.appendChild(script);

        top_menu_height = $('.navbar-affixed-top').height();
        // scroll spy to auto active the nav item
        $('body').scrollspy({target: '#navigation', offset: top_menu_height});
        // scroll to specific id when click on menu
        //$('.navbar-affixed-top .navbar-nav a').click(function (e) {
          //  e.preventDefault();
            //var linkId = $(this).attr('href');
            //scrollTo(linkId);
            //if ($('.navbar-toggle').is(":visible") === true) {
            //    $('.navbar-collapse').collapse('toggle');
            //}
            //$(this).blur();
            //return false;
        //});

    });
});
// scroll animation 
function scrollTo(selectors)
{

    if (!$(selectors).size())
        return;
    var selector_top = $(selectors).offset().top - top_menu_height + 10;
    $('html,body').animate({scrollTop: selector_top}, 'slow');

}
//$(function () {
//    var pgurl = window.location.href.substr(window.location.href
//            .lastIndexOf("/") + 1);
//    $("#nav li a").each(function () {
//        if ($(this).attr("href") == pgurl || $(this).attr("href") == '')
//            $(this).addClass("active");
//    })
//});


$(document).on('ready', function () {
    $('.crosscover').crosscover({
        // controller: true,
        dotNav: true
    });

});
//(function ($) {
//    "use strict";
//    $(document).ready(function () {
//        $('.parallax-bg').scrolly({bgParallax: true});
//    });
//});

/*--------------- PARALLAAX EFFECT -----------------*/
$(document).ready(function () {
    // cache the window object
    $window = $(window);

    $('section[data-type="background"]').each(function () {
        // declare the variable to affect the defined data-type
        var $scroll = $(this);

        $(window).scroll(function () {
            // HTML5 proves useful for helping with creating JS functions!
            // also, negative value because we're scrolling upwards                            
            var yPos = -($window.scrollTop() / $scroll.data('speed'));

            // background position
            var coords = '50%' + yPos + 'px';

            // move the background
            $scroll.css({backgroundPosition: coords});
        }); // end window scroll
    });  // end section function
}); // close out script

/* Create HTML5 element for IE */
document.createElement("section");


// WOW.js initialise
// WOW.js uses animate.css to animate/reveal elements.
// Browse the list of animation effects available here-> https://daneden.github.io/animate.css/
$(function () {
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: true, // default
        live: true // default
    });
    wow.init();
});


/*------------- CLIENT CAROUSEL -------------*/
$(function () {

    var owl = $(".client-slider");
    owl.owlCarousel({
        items: 6, //5 items above 1000px browser width
        itemsDesktop: [1024, 4], //4 items between 1000px and 901px
        itemsDesktopSmall: [900, 3], // betweem 900px and 601px
        itemsTablet: [600, 2], //2 items between 600 and 480
        itemsMobile: [479, 2], //1 item between 480 and 0
        pagination: false, // Show pagination
        navigation: false, // Show navigation
        autoPlay: true
    });
});


/*------------ ABOUT SECTION CUSTOM SCROLLER -------------------*/
$(document).ready(function () {
//$("html").niceScroll({styler: "fb", cursorcolor: "#000"});
    $(".leadership-paragraph").niceScroll({
        cursorcolor: "#cccccc"
    });
    //$("#divexample2").niceScroll("#wrapperexample2", {cursorcolor: "#0F0", boxzoom: true});
    //$("#divexample3").niceScroll("#divexample3 iframe", {boxzoom: true});
});


$(function () {

    $("#typed").typed({
        stringsElement: $('#typed-strings'),
        typeSpeed: 50,
        backDelay: 500,
        loop: true,
        contentType: 'html', // or text
        // defaults to false for infinite loop
        loopCount: true,
        resetCallback: function () {
            newTyped();
        }
    });

    $(".reset").click(function () {
        $("#typed").typed('reset');
    });

});
        