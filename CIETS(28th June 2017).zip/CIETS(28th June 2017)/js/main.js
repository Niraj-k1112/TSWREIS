		/*----------------------------------------------------*/
        /*	open side navigation
        /*----------------------------------------------------*/
		function openNav() {
			document.getElementById("mySidenav").style.width = "250px";
		}
		
		function closeNav() {
			document.getElementById("mySidenav").style.width = "0";
		}
		
		
		


(function($){
    $(document).ready(function(){
		 
	   
	   
	   
	   
	    /*----------------------------------------------------*/
        /*	Sticky Header
        /*----------------------------------------------------*/
        (function() {
            $('#top-bar').scrollToFixed(); // Fixed Top Bar
			$('.nav-box').scrollToFixed(); // Fixed Navigation Bar
         })();
		 
		 

        /*----------------------------------------------------*/
        /*	Same Height Div's
        /*----------------------------------------------------*/
        if(jQuery.isFunction(jQuery.fn.matchHeight)){
            $('.same-height').matchHeight();
        }

        /*----------------------------------------------------*/
        /*	Fraction Slider
        /*----------------------------------------------------*/
        if(jQuery.isFunction(jQuery.fn.fractionSlider)){
            $(window).load(function(){
                $('.slider').fractionSlider({
                    'fullWidth': 			true,
                    'controls': 			true,
                    'responsive': 			true,
                    'dimensions': 			"1170,490",
                    'timeout' :             5000,
                    'increase': 			true,
                    'pauseOnHover': 		true,
                    'slideEndAnimation': 	false,
                    'autoChange':           true
                });
            });
        }
        /*----------------------------------------------------*/
        /*	EasyPie Chart Effects
         /*----------------------------------------------------*/
        if(jQuery.isFunction(jQuery.fn.easyPieChart)){

            // Big EasyPie Chart Effects;
            $('.circular-chart-big').easyPieChart({
                animate : 2000,
                barColor: "#727CB6",
                trackColor : '#f9f9f9',
                scaleColor: false,
                lineWidth: 11,
                size: 180,
                onStep: function(from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent)+'%');
                }
            });

            // Small EasyPie Chart Effects;
            $('.circular-chart-small').easyPieChart({
                size : 120,
                animate : 2000,
                lineWidth : 7,
                lineCap : 'square',
                barColor : '#727CB6',
                trackColor : '#f9f9f9',
                scaleColor : false,
                onStep: function(from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent)+'%');
                }
            });
        }

        /*----------------------------------------------------*/
        /*	Owl Carousel
        /*----------------------------------------------------*/
        if(jQuery.isFunction(jQuery.fn.owlCarousel)){

            // Recent Work Slider
            $("#recent-work-slider").owlCarousel({
                navigation : true,
                pagination : false,
                items : 5,
                itemsDesktop:[1199,4],
                itemsTablet : [768, 3],
                itemsDesktopSmall : [992, 3],
                itemsMobile : [480,1],
                navigationText : ["",""]
            });

            // Post News Slider
            $("#post-slider").owlCarousel({
                navigation : true,
                pagination : false,
                items : 4,
                itemsDesktop:[1199,3],
                itemsDesktopSmall:[980,2],
                itemsMobile : [479,1],
                navigationText : ["",""]
            });
        }

        // ============================
        //  = Scroll event function =
        //  ===========================
        var goScrolling = function(elem) {
            var docViewTop = $(window).scrollTop();
            var docViewBottom = docViewTop + $(window).height();
            var elemTop = elem.offset().top;
            var elemBottom = elemTop + elem.height();
            return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
        };

        //  =======================
        //  = Progress bars =
        //  =======================
        $('.progress_skill .bar').data('width', $(this).width()).css({
            width : 0,
            height:0
        });
        $(window).scroll(function() {
            $('.progress_skill .bar').each(function() {
                if (goScrolling($(this))) {
                    $(this).css({
                        width : $(this).attr('data-value') + '%',
                        height : $(this).attr('data-height') + '%'
                    });
                }
            });
			
			//add remove style margin from nav bar
			var scroll = $(window).scrollTop();
			if (scroll >= 30) {
				$('.nav-box').css({"marginTop": "30px"}); // Fixed Navigation Bar
			} else {
				$('.nav-box').css({"marginTop": "0px"}); // Fixed Navigation Bar
			}
	

        });

        /*===========================================================*/
        /*	Flickr Gallery
        /*===========================================================*/
        $('#flickrFeed').jflickrfeed({
            limit: 9,
            qstrings: {
                //id: '124787947@N07' our id //
                id: '124787947@N07'
            },
            itemTemplate: '<li><a class="mfp-gallery" title="{{title}}" href="{{image_b}}"><i class="fa fa-search"></i><div class="hover"></div></a><img src="{{image_s}}" alt="{{title}}" /></li>'
        });

        /*===========================================================*/
        /*	Isotope Portfolio
        /*===========================================================*/
        if(jQuery.isFunction(jQuery.fn.isotope)){
            jQuery('.portfolio_list').isotope({
                itemSelector : '.list_item',
                layoutMode : 'fitRows',
                animationEngine : 'jquery'
            });

            /* ---- Filtering ----- */
            jQuery('#filter li').click(function(){
                var $this = jQuery(this);
                if ( $this.hasClass('selected') ) {
                    return false;
                } else {
                    jQuery('#filter .selected').removeClass('selected');
                    var selector = $this.attr('data-filter');
                    $this.parent().next().isotope({ filter: selector });
                    $this.addClass('selected');
                    return false;
                }
            });
        }

        /*===========================================================*/
        /*	Image Hover Effect - HoverDirection.js
        /*===========================================================*/
        if(jQuery.isFunction(jQuery.fn.hoverDirection)){
            $('.box').hoverDirection();

            // Example of calling removeClass method after a CSS animation
            $('.box .inner').on('animationend', function (event) {
                var $box = $(this).parent();
                $box.filter('[class*="-leave-"]').hoverDirection('removeClass');
            });
        }

        /*----------------------------------------------------*/
        /*	Magnific Popup
        /*----------------------------------------------------*/
        $('body').magnificPopup({
            type: 'image',
            delegate: 'a.mfp-gallery',
            fixedContentPos: true,
            fixedBgPos: true,
            overflowY: 'auto',
            closeBtnInside: true,
            preloader: true,
            removalDelay: 0,
            mainClass: 'mfp-fade',
            gallery:{enabled:true},
            callbacks: {
                buildControls: function() {
                    console.log('inside'); this.contentContainer.append(this.arrowLeft.add(this.arrowRight));
                }
            }
        });

        $('.mfp-image').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            mainClass: 'mfp-fade',
            image: {
                verticalFit: true
            }
        });

        $('.mfp-youtube, .mfp-vimeo, .mfp-gmaps').magnificPopup({
            disableOn: 700,
            type: 'iframe',
            mainClass: 'mfp-fade',
            removalDelay: 0,
            preloader: false,
            fixedContentPos: false
        });

        /*----------------------------------------------------*/
        /*	Swipe Slider
         /*----------------------------------------------------*/
        window.mySwipe = new Swipe(document.getElementById('slider'), {
            startSlide: 2,
            speed: 400,
            auto: 3000,
            continuous: true,
            disableScroll: false,
            stopPropagation: false,
            callback: function(index, elem) {},
            transitionEnd: function(index, elem) {}
        });

        /*----------------------------------------------------*/
        /*	Accordians & Toggles
         /*----------------------------------------------------*/

        $('.panel-group').on('shown.bs.collapse', function (e) {
            $(e.target).parent().addClass('active_acc');
        });
        $('.panel-group').on('hidden.bs.collapse', function (e) {
            $(e.target).parent().removeClass('active_acc');
        });

        /*----------------------------------------------------*/
        /*	Popover
        /*----------------------------------------------------*/
        $('[data-toggle="popover"]').popover()
        /* ------------------ End Document ------------------ */

        $("body").tooltip({
            selector: '[data-toggle="tooltip"]'
        });
    });
})(this.jQuery);

$(document).ready(function() {

    /*=================
     *	Contact Form
     * #contact
     ===================*/

    try{
        jQuery('#contact').validate({
            submitHandler: function(form) {
                jQuery('#contact .message').hide();
                var ajaxurl = 'contact.php';
                var data = {
                    action: 'contact_us',
                    datas: jQuery(form).serialize()
                };

                jQuery.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: data,
                    success: function(response){
                        jQuery('#contact .message').text(response.error).css({'display' : 'inline-block'});
                    },
                    dataType: 'json'
                });
                return false;
            },
            rules: {
                c_name: {
                    required: true,
                    minlength: 3
                },
                c_mail: {
                    required: true,
                    email: true
                },
                c_subject: {
                    required: true,
                    minlength: 6
                },
                c_message:{
                    required: true,
                    minlength: 20
                }
            }
        });
    }catch(e){

    }

    /*============
     BUTTON UP
     * ===========*/
    var btnUp = $('<div/>', {'class':'btntoTop'});
    btnUp.appendTo('body');
    $(document)
        .on('click', '.btntoTop', function() {
            $('html, body').animate({
                scrollTop: 0
            }, 700);
        });

    $(window)
        .on('scroll', function() {
            if ($(this).scrollTop() > 200)
                $('.btntoTop').addClass('active');
            else
                $('.btntoTop').removeClass('active');
        });
});


/**
 * jQuery Plugin to obtain touch gestures from iPhone, iPod Touch, iPad, and Android mobile phones
 * Common usage: wipe images (left and right to show the previous or next image)
 *
 * @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
 */
(function($){$.fn.touchwipe=function(settings){var config={min_move_x:20,min_move_y:20,wipeLeft:function(){},wipeRight:function(){},wipeUp:function(){},wipeDown:function(){},preventDefaultEvents:true};if(settings)$.extend(config,settings);this.each(function(){var startX;var startY;var isMoving=false;function cancelTouch(){this.removeEventListener('touchmove',onTouchMove);startX=null;isMoving=false}function onTouchMove(e){if(config.preventDefaultEvents){e.preventDefault()}if(isMoving){var x=e.touches[0].pageX;var y=e.touches[0].pageY;var dx=startX-x;var dy=startY-y;if(Math.abs(dx)>=config.min_move_x){cancelTouch();if(dx>0){config.wipeLeft()}else{config.wipeRight()}}else if(Math.abs(dy)>=config.min_move_y){cancelTouch();if(dy>0){config.wipeDown()}else{config.wipeUp()}}}}function onTouchStart(e){if(e.touches.length==1){startX=e.touches[0].pageX;startY=e.touches[0].pageY;isMoving=true;this.addEventListener('touchmove',onTouchMove,false)}}if('ontouchstart'in document.documentElement){this.addEventListener('touchstart',onTouchStart,false)}});return this}})(jQuery);





/*---------------------------------
 NEWS JS
 ----------------------------------*/

$(function() {
    //caching
    //next and prev buttons
    var $cn_next = $('#cn_next');
    var $cn_prev = $('#cn_prev');
    //wrapper of the left items
    var $cn_list = $('#cn_list');
    var $pages = $cn_list.find('.cn_page');
    //how many pages
    var cnt_pages = $pages.length;
    //the default page is the first one
    var page = 1;
    //list of news (left items)
    var $items = $cn_list.find('.cn_item');
    //the current item being viewed (right side)
    var $cn_preview = $('#cn_preview');
    //index of the item being viewed. 
    //the default is the first one
    var current = 1;

    /*
     for each item we store its index relative to all the document.
     we bind a click event that slides up or down the current item
     and slides up or down the clicked one. 
     Moving up or down will depend if the clicked item is after or
     before the current one
     */
    $items.each(function(i) {
        var $item = $(this);
        $item.data('idx', i + 1);

        $item.bind('click', function() {
            var $this = $(this);
            $cn_list.find('.selected').removeClass('selected');
            $this.addClass('selected');
            var idx = $(this).data('idx');
            var $current = $cn_preview.find('.cn_content:nth-child(' + current + ')');
            var $next = $cn_preview.find('.cn_content:nth-child(' + idx + ')');

            if (idx > current) {
                $current.stop().animate({'top': '-300px'}, 600, 'easeOutBack', function() {
                    $(this).css({'top': '310px'});
                });
                $next.css({'top': '310px'}).stop().animate({'top': '5px'}, 600, 'easeOutBack');
            }
            else if (idx < current) {
                $current.stop().animate({'top': '310px'}, 600, 'easeOutBack', function() {
                    $(this).css({'top': '310px'});
                });
                $next.css({'top': '-300px'}).stop().animate({'top': '5px'}, 600, 'easeOutBack');
            }
            current = idx;
        });
    });

    /*
     shows next page if exists:
     the next page fades in
     also checks if the button should get disabled
     */
    $cn_next.bind('click', function(e) {
        var $this = $(this);
        $cn_prev.removeClass('disabled');
        ++page;
        if (page == cnt_pages)
            $this.addClass('disabled');
        if (page > cnt_pages) {
            page = cnt_pages;
            return;
        }
        $pages.hide();
        $cn_list.find('.cn_page:nth-child(' + page + ')').fadeIn();
        e.preventDefault();
    });
    /*
     shows previous page if exists:
     the previous page fades in
     also checks if the button should get disabled
     */
    $cn_prev.bind('click', function(e) {
        var $this = $(this);
        $cn_next.removeClass('disabled');
        --page;
        if (page == 1)
            $this.addClass('disabled');
        if (page < 1) {
            page = 1;
            return;
        }
        $pages.hide();
        $cn_list.find('.cn_page:nth-child(' + page + ')').fadeIn();
        e.preventDefault();
    });

});



// News Ticker JS//
$('a[href*=#]').click(function(e) {
    var href = $.attr(this, 'href');
    if (href != "#") {
        $('html, body').animate({
            scrollTop: $(href).offset().top - 74
        }, 500);
    }
    else {
        $('html, body').animate({
            scrollTop: 0
        }, 500);
    }
    return false;
});
var nt_example1 = $('#nt-example1').newsTicker({
    row_height: 73,
    max_rows: 4,
    duration: 4000,
    prevButton: $('#nt-example1-prev'),
    nextButton: $('#nt-example1-next')
});

//-----ON SCROLL NAVIGATIN FIXED JS --------//
$(document).ready(function() {
    var navpos = $('.main-nav-sctn').offset();
    console.log(navpos.top);
    $(window).bind('scroll', function() {
        if ($(window).scrollTop() > navpos.top) {
            $('.main-nav-sctn').addClass('navbar-fixed-top');
        }
        else {
            $('.main-nav-sctn').removeClass('navbar-fixed-top');
        }
    });
});


/*=== Datepicker Script ===*/			



	
	