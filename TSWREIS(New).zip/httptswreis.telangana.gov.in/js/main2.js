/*------------- Fixed Header top -------------*/
$(window).scroll(function(){
  var sticky = $('.sticky'),
      scroll = $(window).scrollTop();

  if (scroll >= 100) sticky.addClass('scroll_hd');
  else sticky.removeClass('scroll_hd');
});


/*------------- Fixed link left -------------*/
$(window).scroll(function(){
  var fl_text = $('.fl_text'),
      scroll = $(window).scrollTop();

  if (scroll >= 200) fl_text.addClass('fl_text_none');
  else fl_text.removeClass('fl_text_none');
  
  $(".form-link").mouseover(function(){
		fl_text.removeClass('fl_text_none');
	});
	
});

/*------------- PAGE CAROUSEL -------------*/
$(document).ready(function(){
	if(jQuery.isFunction(jQuery.fn.owlCarousel)){
		var owl = $("#testimonials");
		owl.owlCarousel({
			items: 5, //5 items above 1000px browser width
			itemsDesktop: [1024, 5], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 4], // betweem 900px and 601px
			itemsTablet: [600, 2], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		var owl = $("#webinars");
		owl.owlCarousel({
			items: 4, //5 items above 1000px browser width
			itemsDesktop: [1024, 4], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 3], // betweem 900px and 601px
			itemsTablet: [600, 2], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		var owl = $("#media_coverage");
		owl.owlCarousel({
			items: 1, //5 items above 1000px browser width
			itemsDesktop: [1024, 1], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 1], // betweem 900px and 601px
			itemsTablet: [600, 1], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		var owl = $("#press_release");
		owl.owlCarousel({
			items: 1, //5 items above 1000px browser width
			itemsDesktop: [1024, 1], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 1], // betweem 900px and 601px
			itemsTablet: [600, 1], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		var owl = $("#corporate_news");
		owl.owlCarousel({
			items: 1, //5 items above 1000px browser width
			itemsDesktop: [1024, 1], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 1], // betweem 900px and 601px
			itemsTablet: [600, 1], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
	}
});


/*************** hide tabning content ***************/
$(document).ready(function(){
    $(".close_tab_view").click(function(){
        $(".tab-pane").removeClass("active");
    });
});

/******************** Back to top ********************/
$(document).ready(function () {
    var btnUp = $('<div/>', {'class':'btntoTop'});
    btnUp.appendTo('body');
    $(document).on('click', '.btntoTop', function() {
		$('html, body').animate({
			scrollTop: 0
		}, 700);
	});
	

	 $(window).on('scroll', function() {
		if ($(this).scrollTop() > 200)
			$('.btntoTop').addClass('active');
		else
			$('.btntoTop').removeClass('active');
      });

	
});

/**************  lik + scroll to Top ************* */
$(document).ready(function() {
	$(".jumper").on("click", function( e ) {
		e.preventDefault();
		$("body, html").animate({    
		scrollTop: $('.sublink-content-box').offset().top-80
		}, 600);
	});
});


/*************** Page Scroll Animateion div ***************/
$(function () {
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: true, // default
        live: true // default
    });
    wow.init();
});

