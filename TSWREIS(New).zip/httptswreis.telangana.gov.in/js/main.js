/*===== Search Input Script =====*/
( function( window ) {
	
	'use strict';
	!String.prototype.trim && (String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, '');
	});

	function UISearch( el, options ) {	
		this.el = el;
		this.inputEl = el.querySelector( 'form > input.sb-search-input' );
		this._initEvents();
	}

	UISearch.prototype = {
		_initEvents : function() {
			var self = this,
				initSearchFn = function( ev ) {
					ev.stopPropagation();
					// trim its value
					self.inputEl.value = self.inputEl.value.trim();
					
					if( !classie.has( self.el, 'sb-search-open' ) ) { // open it
						ev.preventDefault();
						self.open();
					}
					else if( classie.has( self.el, 'sb-search-open' ) && /^\s*$/.test( self.inputEl.value ) ) { // close it
						ev.preventDefault();
						self.close();
					}
				}

			this.el.addEventListener( 'click', initSearchFn );
			this.el.addEventListener( 'touchstart', initSearchFn );
			this.inputEl.addEventListener( 'click', function( ev ) { ev.stopPropagation(); });
			this.inputEl.addEventListener( 'touchstart', function( ev ) { ev.stopPropagation(); } );
		},
		open : function() {
			var self = this;
			classie.add( this.el, 'sb-search-open' );
			var bodyFn = function( ev ) {
				self.close();
				this.removeEventListener( 'click', bodyFn );
				this.removeEventListener( 'touchstart', bodyFn );
			};
			document.addEventListener( 'click', bodyFn );
			document.addEventListener( 'touchstart', bodyFn );
		},
		close : function() {
			this.inputEl.blur();
			classie.remove( this.el, 'sb-search-open' );
		}
	}

	// add to global namespace
	window.UISearch = UISearch;

} )( window );

new UISearch( document.getElementById( 'sb-search' ) );


/*------------- Fixed Header -------------*/
$(window).scroll(function(){
  var sticky = $('.sticky'),
      scroll = $(window).scrollTop();

  if (scroll >= 100) sticky.addClass('scroll_hd');
  else sticky.removeClass('scroll_hd');
});


/******************** Back to top ********************/
$(document).ready(function () {
    var btnUp = $('<div/>', {'class':'btntoTop'});
    btnUp.appendTo('body');
    $(document).on('click', '.btntoTop', function() {
		$('html, body').animate({
			scrollTop: 0
		}, 700);
	});
	

	 $(window).on('scroll', function() {
		if ($(this).scrollTop() > 200)
			$('.btntoTop').addClass('active');
		else
			$('.btntoTop').removeClass('active');
      });
	
});


/*------------- Menu Hover Header -------------*/
$(document).ready(function(){
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');       
        }
    );
});


/*------------- PAGE CAROUSEL -------------*/
$(document).ready(function(){
	if(jQuery.isFunction(jQuery.fn.owlCarousel)){
		// Experts Slider
		$("#experts").owlCarousel({
			items : 5,
			itemsDesktop:[1300,4],
			itemsDesktopSmall : [992, 3],
			itemsTablet : [768, 3],
			itemsTabletSmall : [767, 2],
			itemsMobile : [530,1],
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		// Patient Testimonial Slider
		$("#patient_testimonial").owlCarousel({
			items : 4,
			itemsDesktop:[1024,3],
			itemsDesktopSmall : [992, 3],
			itemsTablet : [768, 2],
			itemsTabletSmall : [600, 2],
			itemsMobile : [480,1],
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
		
		var owl = $("#webinars");
		owl.owlCarousel({
			items: 4, //5 items above 1000px browser width
			itemsDesktop: [1024, 4], //4 items between 1000px and 901px
			itemsDesktopSmall: [900, 3], // betweem 900px and 601px
			itemsTablet: [600, 2], //2 items between 600 and 480
			itemsMobile: [479, 1], //1 item between 480 and 0
			pagination: false, // Show pagination
			navigation: true, // Show navigation
			autoPlay: true,
			navigationText : ["",""]
		});
	}
	
});

/******************** Back to top ********************/
$(document).ready(function () {
    var btnUp = $('<div/>', {'class':'btntoTop'});
    btnUp.appendTo('body');
    $(document).on('click', '.btntoTop', function() {
		$('html, body').animate({
			scrollTop: 0
		}, 700);
	});
	

	 $(window).on('scroll', function() {
		if ($(this).scrollTop() > 200)
			$('.btntoTop').addClass('active');
		else
			$('.btntoTop').removeClass('active');
      });
	
});



/*************** Page Scroll Animateion div ***************/
$(function () {
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: true, // default
        live: true // default
    });
    wow.init();
});

/*------------- Full Screen Video -------------*/
/*fullscreen();
$(window).resize(fullscreen);
$(window).scroll(headerParallax);

function fullscreen() {
    var page_slider = $('.page_slider');
    var windowH = $(window).height();
    var windowW = $(window).width();

    page_slider.width(windowW);
    page_slider.height(windowH);
}

*/

/*===== News Ticket Script =====*/
var nt_example1 = $('#ntc-crclr-wdgt').newsTicker({
                row_height: 65,
                max_rows: 5,
                duration: 4000,
                prevButton: $('#ntc-crclr-prev'),
                nextButton: $('#ntc-crclr-next')
            });
           var nt_example1 = $('#recent-updates-box').newsTicker({
                row_height: 65,
                max_rows: 1,
                duration: 3000
            });
			
			
           $(window).scroll(function() {    
			var scroll = $(window).scrollTop();
		
			if (scroll >= 30) {
				$(".clg-page-nav").addClass("navbar-fixed-top");
			} else {
				$(".clg-page-nav").removeClass("navbar-fixed-top");
			}
		});
   




